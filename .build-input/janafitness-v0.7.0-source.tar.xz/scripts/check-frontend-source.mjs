import fs from "node:fs";
import path from "node:path";
let ts;
try {
  ts = (await import("typescript")).default;
} catch {
  ts = (await import("/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js")).default;
}

const root = process.cwd();
const sourceRoot = path.join(root, "src");
const files = [];

function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (/\.(ts|tsx)$/.test(entry.name)) files.push(full);
  }
}

function resolvesLocalImport(specifier, fromFile) {
  if (!specifier.startsWith("@/") && !specifier.startsWith(".")) return true;
  const base = specifier.startsWith("@/")
    ? path.join(sourceRoot, specifier.slice(2))
    : path.resolve(path.dirname(fromFile), specifier);
  return [base, `${base}.ts`, `${base}.tsx`, `${base}.json`, path.join(base, "index.ts"), path.join(base, "index.tsx")]
    .some((candidate) => fs.existsSync(candidate));
}

walk(sourceRoot);
let failed = false;
for (const file of files) {
  const source = fs.readFileSync(file, "utf8");
  const result = ts.transpileModule(source, {
    fileName: file,
    reportDiagnostics: true,
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
      jsx: ts.JsxEmit.ReactJSX,
      isolatedModules: true,
    },
  });
  for (const diagnostic of result.diagnostics ?? []) {
    failed = true;
    const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n");
    console.error(`${path.relative(root, file)}: ${message}`);
  }

  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
  for (const statement of ast.statements) {
    if ((ts.isImportDeclaration(statement) || ts.isExportDeclaration(statement)) && statement.moduleSpecifier && ts.isStringLiteral(statement.moduleSpecifier)) {
      const specifier = statement.moduleSpecifier.text;
      if (!resolvesLocalImport(specifier, file)) {
        failed = true;
        console.error(`${path.relative(root, file)}: chybí lokální import ${specifier}`);
      }
    }
  }
}

if (failed) process.exit(1);
console.log(`Frontend source: ${files.length} TS/TSX souborů má platnou syntaxi a lokální importy.`);
