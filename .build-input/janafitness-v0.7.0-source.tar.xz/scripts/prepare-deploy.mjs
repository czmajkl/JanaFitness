import { cp, mkdir, rm, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";

const root = process.cwd();
const out = path.join(root, "out");
const deploy = path.join(root, "deploy");
if (!existsSync(out)) {
  throw new Error("Chybí složka out/. Nejdřív spusťte npm run build.");
}
await rm(deploy, { recursive: true, force: true });
await mkdir(path.join(deploy, "web"), { recursive: true });
await mkdir(path.join(deploy, "private"), { recursive: true });
await cp(out, path.join(deploy, "web"), { recursive: true });
await cp(path.join(root, "php-api"), path.join(deploy, "web", "api"), { recursive: true });
await cp(path.join(root, "private", "config.example.php"), path.join(deploy, "private", "config.example.php"));
await cp(path.join(root, "database"), path.join(deploy, "database"), { recursive: true });
await writeFile(path.join(deploy, "web", ".htaccess"), `Options -Indexes\nAddDefaultCharset UTF-8\nDirectoryIndex index.html index.php\nErrorDocument 404 /404.html\n<IfModule mod_headers.c>\n  Header always set X-Content-Type-Options "nosniff"\n  Header always set Referrer-Policy "strict-origin-when-cross-origin"\n  Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"\n</IfModule>\n`);
console.log("Připraveno v deploy/: web/ nahrajte do /web, private/ vedle /web.");
