import fs from "node:fs";
import path from "node:path";

const roots = ["src", "php-api", "database", "private"];
const allowed = new Set([".ts", ".tsx", ".php", ".sql", ".json", ".css", ".md", ".mjs"]);
const decoder = new TextDecoder("utf-8", { fatal: true });
const suspicious = ["\uFFFD", "\u00C3", "\u00C5", "\u00C4", "\u00C2", "\u00E2"];
let failed = false;
let count = 0;

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (allowed.has(path.extname(entry.name))) check(full);
  }
}

function check(file) {
  count += 1;
  let text;
  try {
    text = decoder.decode(fs.readFileSync(file));
  } catch {
    console.error(`${file}: invalid UTF-8`);
    failed = true;
    return;
  }
  for (const marker of suspicious) {
    if (text.includes(marker)) {
      console.error(`${file}: suspicious encoding marker ${JSON.stringify(marker)}`);
      failed = true;
    }
  }
}

for (const root of roots) walk(root);
const packages = fs.readFileSync("src/content/packages.ts", "utf8");
if (!packages.includes("V\u00fdkon")) {
  console.error("src/content/packages.ts: expected Czech title Vykon with y-acute is missing");
  failed = true;
}
if (failed) process.exit(1);
console.log(`UTF-8 source check: ${count} files OK.`);
