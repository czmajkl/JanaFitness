#!/usr/bin/env bash
set -euo pipefail
: "${FTP_HOST:?Chybi FTP_HOST}"
: "${FTP_USER:?Chybi FTP_USER}"
: "${FTP_PASSWORD:?Chybi FTP_PASSWORD}"
command -v lftp >/dev/null || { echo "Chybi lftp." >&2; exit 1; }
[ -d deploy/web ] || { echo "Nejdriv spust npm run deploy:prepare." >&2; exit 1; }
lftp -u "$FTP_USER","$FTP_PASSWORD" "$FTP_HOST" <<LFTP
set ftp:ssl-force true
set ssl:verify-certificate true
mirror --reverse --delete --verbose deploy/web /web
mirror --reverse --verbose deploy/private /private
quit
LFTP
